#!/bin/sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./lib

bin/xpathtest $1 $2


